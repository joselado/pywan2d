import numpy as np



def MoS2(path=None):
  """Return the Hamiltonian of MoS2"""
  namefile = "MoS2.dat" # name of the file
  if path is not None: namefile = path + namefile # full path
  return generator_function(namefile,fermi=4.4475) 



def MoS2_soc(path=None):
  """Return the Hamiltonian of MoS2"""
  namefile = "MoS2_soc.dat" # name of the file
  if path is not None: namefile = path + namefile # full path
  return generator_function(namefile,fermi=2.6814) 





def phosphorene(path=None):
  """Return the Hamiltonian of phosphorene"""
  namefile = "phosphorene.dat" # name of the file
  if path is not None: namefile = path + namefile # full path
  return generator_function(namefile,fermi=-3) 





def generator_function(namefile,fermi=0.0):
  """Return a function that generates the Hamiltonian in every
  k-point """
  mt = np.genfromtxt(namefile) # get file
  m = mt.transpose()
  # maximun cell with interaction
  nmax = np.max([np.max(np.abs(m[0])),np.max(np.abs(m[1])),np.max(np.abs(m[2]))])
  norb = np.max([np.max(np.abs(m[3])),np.max(np.abs(m[4]))]) # number of elements
  norb = int(norb)
  nmax = int(nmax)
  print("Reading Hamiltonian with dimension",norb)
  
  
  # read the hamiltonian matrices
  class Hopping: pass # create empty class
  tlist = []
  # this way is a bit slower, but it works so far
  for i in range(-nmax,nmax+1):
    for j in range(-nmax,nmax+1):
#      for k in range(-nmax,nmax+1):
        k = 0     # for 2d this loop is skipable
        t = Hopping() # create hopping
        t.dir = [i,j,k] # direction
        t.m = np.matrix(np.zeros((norb,norb),dtype=np.complex))
        for l in mt: # look into the file
          if i==int(l[0]) and j==int(l[1]) and k==int(l[2]):
            ii = int(l[3])-1 # index of the matrix
            jj = int(l[4])-1 # index of the matrix
            t.m[ii,jj] = l[5] + 1j*l[6] # store element
            # shift fermi energy
            if ((i==0) and (j==0) and (k==0) and (ii==jj)):
              t.m[ii,jj] -= fermi # shift to zero
        tlist.append(t) # store hopping
  
  #########################
  # now define the function 
  #########################
  def gethk(k):
    """Return the k-dependent Hamiltonian"""
    h = tlist[0].m*0.0 # initialice hamiltonian
    k = np.array(k) # transform into a vector
    if len(k)==2: k = np.array([k[0],k[1],0.]) # set as 3d
    for t in tlist:
      phi = np.dot(np.array(t.dir),k) # k.r
      h += t.m*np.exp(1j*2.*np.pi*phi) # add complex hopping
    return h
  
  return gethk # return function
  
  
