


if __name__=="__main__": # main program
  use_soc = True # use the Hamiltonian with SOC
  import hamiltonian # library that provides the Hamiltonians
  path = None # if you are in a different folder, put the direction
              # of the folder where the .dat files are stored
# get the function that  generates the Bloch Hamiltonian
  # choose between the three options
  if use_soc:  hkgen = hamiltonian.MoS2_soc(path=path)  # with SOC
  else: hkgen = hamiltonian.MoS2(path=path)  # without SOC


  # hkgen is a function that takes a 2d (or 3d) k vector, and
  # yields the Hamiltonian at that key point, the k-vectors
  # are units of the G-vectors, so that the BZ goes from [-.5,.5]


  import scipy.linalg as lg # linear algebre libraries
  import matplotlib.pyplot as plt # plotting library
  import numpy as np
  # lets just plot the bands for phosphorene
  G0 = np.array([0.,0.,0.]) # Gamma point
  G1 = np.array([1,-1,0.]) # M point
  corners = [(G0,G1)] # path in the BZ
  steps = np.linspace(0.,1.,800) # 50 steps between corners
  inds = np.zeros(hkgen(G0).shape[0]) # indexes for plotting
  fo = open("BANDS.OUT","w")
  for (k0,k1) in corners: # loop over pairs
    for s in steps: # loop over intermadiate points
      k = k0 + (k1-k0)*s # kpoint
      h = hkgen(k) # get the matrix
      es = lg.eigvalsh(h) # eigenvalues 
      plt.scatter(inds,es,c="red",edgecolors='none',s=30)
      for (i,e) in zip(inds,es): fo.write(str(i)+"   "+str(e)+"\n")
      inds += 1 # increase for the next k-point
  fo.close()
  plt.scatter([],[],c="red",edgecolors='none',s=80,label="Wannier bands")

  # now plot the DFT bands over the Wannier
  if use_soc: namefile = "BANDS_MoS2_soc_DFT.OUT"
  else: namefile = "BANDS_MoS2_DFT.OUT"
  m = np.genfromtxt(namefile).transpose() # import data
  kdft,edft = m[0],m[1] # kpoint and energy
  kdft = kdft/np.max(kdft)*(np.max(inds)-1) # normalize as the wannier
  plt.scatter(kdft,edft,label="DFT bands",s=10,edgecolors='none') # scatter

  plt.xlim([0,max(inds)])
  plt.ylim([-3,3])
  plt.xlabel("K-path")
  plt.ylabel("Energy [eV]")
  plt.legend()
  plt.show() # show the plot
